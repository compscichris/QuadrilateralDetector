//Christopher Chen

import UIKit

var str = "Hello, playground"

// |---------------------|
// |                     |
// |                     |
// |                     |
// |                     |
// |                     |
// |_____________________|

//side1 or s1 = left
//side2 or s2 = top
//side3 or s3 = right
//side4 or s4 = bottom
//angle1 or a1 = topleft
//angle2 or a2 = topright
//angle3 or a3 = bottomright
//angle4 or a4 = bottomleft


/**
 Quadrilateral is a class that is used to represent any shape with 4 sides.
 */
class Quadrilateral
{
    var name : String
    var side1 : Double
    var side2 : Double
    var side3 : Double
    var side4 : Double
    var angle1 : Int
    var angle2 : Int
    var angle3 : Int
    var angle4 : Int
    //initialize class objects with the 4 lengths and 3 angles.
    init(_ s1 : Double, _ s2 : Double, _ s3 : Double, _ s4 : Double, _ a1 : Int, _ a2 : Int, _ a3 : Int)
    {
        name = "Quadrilateral"
        side1 = s1
        side2 = s2
        side3 = s3
        side4 = s4
        angle1 = a1
        angle2 = a2
        angle3 = a3
        let tempDiff = a1 + a2 + a3
        angle4 = 360 - tempDiff
    }
    //perimeter = sum of all sides.
    var perimeter : Double
    {
        return self.side1 + self.side2 + self.side3 + self.side4
    }
    // |---------------------|
    // |                     |
    // |                     |
    // |                     |
    // |                     |
    // |                     |
    // |_____________________|

    //side1 = left
    //side2 = top
    //side3 = right
    //side4 = bottom
    //angle1 = topleft
    //angle2 = topright
    //angle3 = bottomright
    //angle4 = bottomleft
    //law of cosines: c^2 = a^2 + b^2 -2ab * cos(C)
    //diagonal1 = line from angle1 to angle3, a = side1, b = side4, C = angle4
    var diagonal1 : Double
    {
        let cosineC : Double = cos((Double(angle4) * Double.pi / 180))
        let asquare : Double = (side1 * side1)
        let bsquare : Double = (side4 * side4)
        let two_AB : Double = 2 * side1 * side4
        let csquare : Double = asquare + bsquare - (two_AB * cosineC)
        if(csquare > 0)
        {
            return sqrt(csquare)
        }
        else{
            return -1
        }
    }
    //diagonal2 = line from angle2 to angle4, a = side3, b = side4, C = angle2
    var diagonal2 : Double
    {
        let cosineC : Double = cos((Double(angle3) * Double.pi / 180))
        let asquare : Double = (side3 * side3)
        let bsquare : Double = (side4 * side4)
        let two_AB : Double = 2 * side3 * side4
        let csquare : Double = asquare + bsquare - (two_AB * cosineC)
        if(csquare > 0)
        {
            return sqrt(csquare)
        }
        else{
            return -1
        }
    }
    //using diagonal1, we create 2 triangles, and calculate their areas, yielding the total area
    var triangle1Area : Double
    {
        let sineTheta : Double = sin(Double(angle4) * Double.pi / 180)
        let a : Double = side1
        let b : Double = side4
        let area : Double = a * b * sineTheta / 2
        if(area > 0)
        {
            return area
        }
        else{
            return -1
        }
    }
    var triangle2Area : Double
    {
        let sineTheta = sin(Double(angle2) * Double.pi / 180)
        let a : Double = side3
        let b : Double = side2
        let area : Double = a * b * sineTheta / 2
        if(area > 0)
        {
            return area
        }
        else{
            return -1
        }
    }
    var totalArea : Double
    {
        if(self.triangle1Area == -1 || self.triangle2Area == -1)
        {
            return -1
        }
        else{
            return triangle1Area + triangle2Area
        }
        
    }
    //printDetails() is a method that uses member fields and variables to print out the information of each quadrilateral,
    //including all of the sides, angles, and diagonals. It also prints out the triangle areas made from the first diagonal,
    //and the total area of that quadrilateral. It specifies which quadrilateral class it was made with.
    func printDetails()
    {
        print("Name: \(name)")
        print("Side 1: \(side1)")
        print("Side 2: \(side2)")
        print("Side 3: \(side3)")
        print("Side 4: \(side4)")
        print("Angle 1: \(angle1)")
        print("Angle 2: \(angle2)")
        print("Angle 3: \(angle3)")
        print("Angle 4: \(angle4)")
        print("Perimeter: \(self.perimeter)")
        if(self.diagonal1 != -1 && self.diagonal2 != -1)
        {
            print("Diagonal 1: \(self.diagonal1)")
            print("Diagonal 2: \(self.diagonal2)")
            if(self.triangle1Area != -1 && self.triangle2Area != -1)
            {
                print("Using Diagonal 1:")
                print("Triangle 1 Area: \(self.triangle1Area)")
                print("Triangle 2 Area: \(self.triangle2Area)")
                print("Total Area of this \(name): \(self.totalArea)")
            }
            else{
                print("This shape has errors")
            }
        }
        else{
            print("This shape has errors")
        }
        print("\n")
    }
}
/**
Parallelogram is a class that is used to represent a Quadrilateral class that is of a parallelogram classification.
*/
class Parallelogram : Quadrilateral
{
    //initialize class objects with the 2 pairs of size lengths and angle between side1 and side2
    init(_ s1 : Double, _ s2 : Double, _ a1 : Int)
    {
        super.init(s1, s2, s1, s2, a1, 180-a1, a1)
        self.name = "Parallelogram"
    }
}
/**
Rectangle is a class that is used to represent a Quadrilateral class that is of a rectangle classification.
*/
class Rectangle : Quadrilateral
{
    //initialize class objects with the 2 pairs of size lengths
    init(_ s1 : Double, _ s2 : Double)
    {
        super.init(s1, s2, s1, s2, 90, 90, 90)
        self.name = "Rectangle"
    }
}

//Print Output and all calculations
var testQuad = Quadrilateral(4,4,4,4,90,90,90)
var testPara = Parallelogram(4,4,120)
var testRect = Rectangle(5,6)

testQuad.printDetails()
testPara.printDetails()
testRect.printDetails()
